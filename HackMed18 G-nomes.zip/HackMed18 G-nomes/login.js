let username = 'DrGnome';
let userpass = 'Genome';

let name = 'DrGnome';
let password = 'Genome';

if (username===name && userpass===password) {
  console.log('Logging in...');
} else {
  console.log('Incorrect username or password.');
}
